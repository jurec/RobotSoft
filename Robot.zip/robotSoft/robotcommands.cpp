#include "robotcommands.h"

robotCommands::robotCommands(QObject *parent) :
    QObject(parent)
{
}
