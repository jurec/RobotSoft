#include <Command/command.h>

command::command(QObject *parent):
        QObject(parent)
{

}
